### Install required packages
conda install pytorch=2.0 torchvision==0.13 torchaudio=0.12 cudatoolkit=11.3 -c pytorch \
pip install -r requirements.txt