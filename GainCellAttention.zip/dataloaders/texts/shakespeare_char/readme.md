
# tiny shakespeare, character-level

Tiny shakespeare, of the good old char-rnn fame :) Treated on character-level.

After running `prepare.py`:

- train.bin has 1,003,854 tokens
- val.bin has 111,540 tokens
